DROP VIEW BANCOS.VWSALDO_CUOTAS;

/* Formatted on 20/11/2013 07:50:54 a.m. (QP5 v5.115.810.9015) */
CREATE OR REPLACE FORCE VIEW BANCOS.VWSALDO_CUOTAS
(
   COD_CIA,
   COD_CUOTA,
   COD_PRESTAMO,
   NOM_CORTO,
   DESCRIPCION_TIPOCREDITO,
   REF_PRESTAMO,
   NUMERO_CUOTA,
   VALOR_CUOTA,
   SALDO_CUOTA,
   FECHA_PAGO,
   SALDO_CAPITALANT,
   VALOR_AMORTIZACION,
   VALOR_INTERES,
   SALDO_CAPITAL
)
AS
     SELECT   PB_DETALLEPRESTAMOS.COD_CIA,
              PB_DETALLEPRESTAMOS.COD_CUOTA,
              pb_detalleprestamos.cod_prestamo,
              BANCOS.NOM_CORTO,
              PB_TIPOS_CREDITOS.DESCRIPCION_TIPOCREDITO,
              PB_PRESTAMOS.REF_PRESTAMO,
              PB_DETALLEPRESTAMOS.NUMERO_CUOTA,
              PB_DETALLEPRESTAMOS.VALOR_CUOTA,
              PB_DETALLEPRESTAMOS.VALOR_CUOTA
              - NVL (
                   SUM (PB_DETALLEPAGO.ABONO_INTERES)
                   + SUM (PB_DETALLEPAGO.ABONO_AMORTIZACION),
                   0
                )
                 SALDO_CUOTA,
              PB_DETALLEPRESTAMOS.FECHA_PAGO,
              PB_DETALLEPRESTAMOS.SALDO_CAPITAlANT,
              CASE
                 WHEN PB_DETALLEPRESTAMOS.VALOR_AMORTIZACION
                      - NVL (SUM(PB_DETALLEPAGO.ABONO_AMORTIZACION), 0) <> 0
                 THEN
                    PB_DETALLEPRESTAMOS.VALOR_AMORTIZACION
                    - NVL (SUM (PB_DETALLEPAGO.ABONO_INTERES), 0)
                 ELSE
                    0
              END
                 VALOR_AMORTIZACION,
              CASE
                 WHEN PB_DETALLEPRESTAMOS.VALOR_INTERES
                      - NVL (SUM(PB_DETALLEPAGO.ABONO_INTERES), 0) <> 0
                 THEN
                    PB_DETALLEPRESTAMOS.VALOR_INTERES
                    - NVL (SUM (PB_DETALLEPAGO.ABONO_INTERES), 0)
                 ELSE
                    0
              END
                 VALOR_INTERES,
              PB_DETALLEPRESTAMOS.SALDO_CAPITAL
       FROM                  pb_detalleprestamos
                          INNER JOIN
                             pb_prestamos
                          ON pb_detalleprestamos.cod_cia = pb_prestamos.COD_CIA
                             AND PB_DETALLEPRESTAMOS.COD_PRESTAMO =
                                   pb_prestamos.COD_PRESTAMO
                       LEFT OUTER JOIN
                          PB_DETALLEPAGO
                       ON pb_detalleprestamos.COD_CIA = PB_DETALLEPAGO.COD_CIA
                          AND PB_DETALLEPRESTAMOS.COD_CUOTA =
                                PB_DETALLEPAGO.COD_CUOTA
                    INNER JOIN
                       BANCOS
                    ON PB_PRESTAMOS.COD_CIA = BANCOS.COD_CIA
                       AND PB_PRESTAMOS.COD_BANCO = BANCOS.COD_BANCO
                 INNER JOIN
                    PB_LINEASCREDITO
                 ON PB_PRESTAMOS.COD_CIA = PB_LINEASCREDITO.COD_CIA
                    AND PB_PRESTAMOS.COD_LINEA = PB_LINEASCREDITO.COD_LINEA
              INNER JOIN
                 PB_TIPOS_CREDITOS
              ON PB_LINEASCREDITO.COD_CIA = PB_TIPOS_CREDITOS.COD_CIA
                 AND PB_LINEASCREDITO.COD_TIPOCREDITO =
                       PB_TIPOS_CREDITOS.COD_TIPOCREDITO
      WHERE   PB_DETALLEPRESTAMOS.NUMERO_CUOTA <> 0
   GROUP BY   PB_DETALLEPRESTAMOS.COD_CIA,
              pb_detalleprestamos.cod_prestamo,
              PB_DETALLEPRESTAMOS.COD_CUOTA,
              PB_PRESTAMOS.REF_PRESTAMO,
              PB_DETALLEPRESTAMOS.NUMERO_CUOTA,
              PB_DETALLEPRESTAMOS.VALOR_CUOTA,
              PB_DETALLEPRESTAMOS.FECHA_PAGO,
              PB_DETALLEPRESTAMOS.SALDO_CAPITAlANT,
              PB_DETALLEPRESTAMOS.VALOR_AMORTIZACION,
              PB_DETALLEPRESTAMOS.VALOR_INTERES,
              PB_DETALLEPRESTAMOS.SALDO_CAPITAL,
              BANCOS.NOM_CORTO,
              PB_TIPOS_CREDITOS.DESCRIPCION_TIPOCREDITO
   ORDER BY   PB_DETALLEPRESTAMOS.FECHA_PAGO,
              pb_detalleprestamos.cod_prestamo,
              pb_detalleprestamos.numero_cuota;


DROP PUBLIC SYNONYM VWSALDO_CUOTAS;

CREATE PUBLIC SYNONYM VWSALDO_CUOTAS FOR BANCOS.VWSALDO_CUOTAS;


GRANT DELETE, INSERT, SELECT, UPDATE ON BANCOS.VWSALDO_CUOTAS TO OPERA_BANCOS;

GRANT DELETE, INSERT, SELECT, UPDATE ON BANCOS.VWSALDO_CUOTAS TO SUPERVISOR_BANCOS;

